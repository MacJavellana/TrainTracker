package com.mobdeve.s14.javellana.mac.mp_traintracker

import com.google.android.gms.maps.model.LatLng

data class Station(val name: String, val location: LatLng)
